<?php

namespace App\DataFixtures;

use App\Entity\Classroom;
use Cocur\Slugify\Slugify;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class ClassroomFixtures extends Fixture
{
	public function load(ObjectManager $manager)
	{
		for ($i=1; $i < 6; $i++) {
			$slugify = new Slugify();
			$degree = "BTS GPME";
			$startDate = new \DateTime("2010/02/16");
			$startDate = date_format($startDate,'Y');
			$endDate = new \DateTime("2012/02/16");
			$endDate = date_format($endDate,'Y');
			$slug = $slugify->slugify($degree."-".$startDate."-".$endDate);

			$classroom = new Classroom();
			$classroom->setDegree($degree)
			->setStartDate(new \DateTime("2010/02/16"))
			->setEndDate(new \DateTime("2012/02/16"))
			->setSlug($slug)
			->setExist(1);
			
			$manager->persist($classroom);
		}

		$manager->flush();
	}
}
