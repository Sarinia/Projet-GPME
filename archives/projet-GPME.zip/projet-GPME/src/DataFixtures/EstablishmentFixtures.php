<?php

namespace App\DataFixtures;

use App\Entity\Department;
use App\Entity\Establishment;
use Cocur\Slugify\Slugify;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class EstablishmentFixtures extends Fixture
{
	public function load(ObjectManager $manager)
	{
		for ($i=1; $i < 4; $i++) { 
			$department = new Department();
			$department->setName("departement$i")
			->setExist(1);

			for ($k=1; $k < 3; $k++) { 
				$slugify = new Slugify();
				$name = "établissement$k";
				$slug = $slugify->slugify($name);

				$establishment = new Establishment();
				$establishment->setDepartment($department)
				->setName($name)
				->setAdress("adresse$k")
				->setPostalCode(06000)
				->setCity("ville$k")
				->setBackgroundUrl("https://via.placeholder.com/1920x1080.png")
				->setSlug($slug)
				->setExist(1);

				$manager->persist($establishment);
			}

			$manager->persist($department);
		}
	
		$manager->flush();
	}
}
