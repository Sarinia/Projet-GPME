<?php

namespace App\DataFixtures;

use App\Entity\Admin;
use App\Entity\Sadmin;
use App\Entity\Student;
use App\Entity\Teacher;
use App\Entity\User;
use Cocur\Slugify\Slugify;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class UserFixtures extends Fixture
{
	private $encoder;

	public function __construct(UserPasswordEncoderInterface $encoder){
		$this->encoder=$encoder;
	}

	public function load(ObjectManager $manager)
	{
		// Super-Administrateur
		for ($i=1; $i < 6; $i++) { 
			$user = new User();

			$slugify = new Slugify();
			$lastName = "sadmin$i";
			$firstName = "sadmin$i";
			$slug = $slugify->Slugify($lastName."-".$firstName);

			$encoded = $this->encoder->encodePassword($user, "pass");

			$user->setLastName($lastName)
			->setFirstName($firstName)
			->setEmail("sadmin@email.fr")
			->setHash($encoded)
			->setSlug($slug)
			->setTitle("ROLE_SADMIN");
			$manager->persist($user);

			$sadmin = new Sadmin();
			$sadmin->setUser($user);
			$manager->persist($sadmin);
		}

		// Administrateur
		for ($i=1; $i < 6; $i++) { 
			$user = new User();

			$slugify = new Slugify();
			$lastName = "admin$i";
			$firstName = "admin$i";
			$slug = $slugify->Slugify($lastName."-".$firstName);

			$encoded = $this->encoder->encodePassword($user, "pass");

			$user->setLastName($lastName)
			->setFirstName($firstName)
			->setEmail("admin@email.fr")
			->setHash($encoded)
			->setSlug($slug)
			->setTitle("ROLE_ADMIN");
			$manager->persist($user);

			$admin = new Admin();
			$admin->setUser($user);
			$manager->persist($admin);
		}

		// Teacher
		for ($i=1; $i < 6; $i++) { 
			$user = new User();

			$slugify = new Slugify();
			$lastName = "teacher$i";
			$firstName = "teacher$i";
			$slug = $slugify->Slugify($lastName."-".$firstName);

			$encoded = $this->encoder->encodePassword($user, "pass");

			$user->setLastName($lastName)
			->setFirstName($firstName)
			->setEmail("teacher@email.fr")
			->setHash($encoded)
			->setSlug($slug)
			->setTitle("ROLE_TEACHER");
			$manager->persist($user);

			$teacher = new Teacher();
			$teacher->setUser($user);
			$manager->persist($teacher);
		}

		// Student
		for ($i=1; $i < 6; $i++) { 
			$user = new User();

			$slugify = new Slugify();
			$lastName = "student$i";
			$firstName = "student$i";
			$slug = $slugify->Slugify($lastName."-".$firstName);

			$encoded = $this->encoder->encodePassword($user, "pass");

			$user->setLastName($lastName)
			->setFirstName($firstName)
			->setEmail("student@email.fr")
			->setHash($encoded)
			->setSlug($slug)
			->setTitle("ROLE_USER");
			$manager->persist($user);

			$student = new Student();
			$student->setUser($user)
			->setCandidateNb("1000$i")
			->setBirthDate(new \DateTime("2010/02/16"));
			$manager->persist($student);
		}

		$manager->flush();
	}
}
